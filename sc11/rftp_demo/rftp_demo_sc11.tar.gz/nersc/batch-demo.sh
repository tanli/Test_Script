#! /bin/bash

/global/u2/s/shudong/sync/nersc/batch-nersc2anl-14v14-nodirect.sh &
pid1=$!
/global/u2/s/shudong/sync/nersc/batch-nersc2ornl-10v10-nodirect.sh &
pid2=$!

wait $pid1 $pid2

echo "RFTP demo finished"
