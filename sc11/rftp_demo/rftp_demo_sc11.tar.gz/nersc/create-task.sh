#! /bin/bash

source ./define.sh

rm -rf $taskdir/*

# local
for dir in 1 2 3 4 5 6 7
do
	echo "open 127.0.0.1 18139" > $taskdir/put-local-bc$dir
	echo "user ftp ftp" >> $taskdir/put-local-bc$dir
	echo "prompt" >> $taskdir/put-local-bc$dir
	echo "lcd " $sourcedir >> $taskdir/put-local-bc$dir
	echo "cd " $sinkdir >> $taskdir/put-local-bc$dir
	echo "put bell_curve$dir" >> $taskdir/put-local-bc$dir
	echo "bye" >> $taskdir/put-local-bc$dir
done

for host in $hosteths
do
	for dir in 1 2 3 4 5 6 7
	do
	echo "open $host 18139" > $taskdir/put-$host-bc$dir
	echo "user ftp ftp" >> $taskdir/put-$host-bc$dir
	echo "prompt" >> $taskdir/put-$host-bc$dir
	echo "lcd $sourcedir" >> $taskdir/put-$host-bc$dir
	echo "cd $sinkdir" >> $taskdir/put-$host-bc$dir
	echo "put bell_curve$dir" >> $taskdir/put-$host-bc$dir
	echo "bye" >> $taskdir/put-$host-bc$dir
	done
done

# create put ornl task
for host in $ornlhosts
do
	for dir in 1 2 3 4 5 6 7 8 9 10
	do
	echo "open $host 18139" > $taskdir/put-$host-bc$dir
	echo "user ftp ftp" >> $taskdir/put-$host-bc$dir
	echo "prompt" >> $taskdir/put-$host-bc$dir
	echo "lcd $sourcedir" >> $taskdir/put-$host-bc$dir
	echo "cd $ornlsinkdir" >> $taskdir/put-$host-bc$dir
	echo "put bell_curve$dir" >> $taskdir/put-$host-bc$dir
	echo "bye" >> $taskdir/put-$host-bc$dir
	done
done

# create put ornl lustre task
for host in $ornlhosts
do
	for dir in 1 2 3 4 5 6 7 8 9 10
	do
	echo "open $host 18139" > $taskdir/put-$host-lustre-bc$dir
	echo "user ftp ftp" >> $taskdir/put-$host-lustre-bc$dir
	echo "prompt" >> $taskdir/put-$host-lustre-bc$dir
	echo "lcd $sourcedir" >> $taskdir/put-$host-lustre-bc$dir
	echo "cd $ornlsinkdir" >> $taskdir/put-$host-lustre-bc$dir
	echo "put bell_curve$dir" >> $taskdir/put-$host-lustre-bc$dir
	echo "bye" >> $taskdir/put-$host-lustre-bc$dir
	done
done

# create put anl task
for host in $anlhosts
do
	for dir in 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14
	do
	echo "open $host 18139" > $taskdir/put-$host-bc$dir
	echo "user ftp ftp" >> $taskdir/put-$host-bc$dir
	echo "prompt" >> $taskdir/put-$host-bc$dir
	echo "lcd $sourcememdir" >> $taskdir/put-$host-bc$dir
	echo "cd $anlsinkdir" >> $taskdir/put-$host-bc$dir
	echo "put bell_curve$dir" >> $taskdir/put-$host-bc$dir
	echo "bye" >> $taskdir/put-$host-bc$dir
	done
done
