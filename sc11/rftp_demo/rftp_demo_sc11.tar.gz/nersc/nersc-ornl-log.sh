#! /bin/bash

for i in 1 2 3 4 5 6 7 8 9 10; do
grep "bytes sent" /global/u2/s/shudong/rftp/log/rcftp-nondirectio-bc$i-128K-d32.log | cut -f 5 -d ' '
done

