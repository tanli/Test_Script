#! /bin/bash

source ./define.sh

for host in $hosts
do
	echo "=======ping " $host " ============"
	ping -c 1 $host
	echo
	echo
done
