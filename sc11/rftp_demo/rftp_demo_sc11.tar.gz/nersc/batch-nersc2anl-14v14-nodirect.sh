#! /bin/bash

source ./define.sh

# direct io
for c in 128K
do
        for s in 4
	do
# vlan 654
cmd1="env RCFTPRC=$configdir/rcftprc-nondirectio-$c-$s $rcftpbin -n -i -v < $taskdir/put-10.200.200.30-bc1 > $logdir/nersc-anl-bc1-$c-d$s.log"
cmd2="env RCFTPRC=$configdir/rcftprc-nondirectio-$c-$s $rcftpbin -n -i -v < $taskdir/put-10.200.200.31-bc2 > $logdir/nersc-anl-bc2-$c-d$s.log"
cmd3="env RCFTPRC=$configdir/rcftprc-nondirectio-$c-$s $rcftpbin -n -i -v < $taskdir/put-10.200.200.32-bc3 > $logdir/nersc-anl-bc3-$c-d$s.log"
cmd4="env RCFTPRC=$configdir/rcftprc-nondirectio-$c-$s $rcftpbin -n -i -v < $taskdir/put-10.200.200.33-bc4 > $logdir/nersc-anl-bc4-$c-d$s.log"
cmd5="env RCFTPRC=$configdir/rcftprc-nondirectio-$c-$s $rcftpbin -n -i -v < $taskdir/put-10.200.200.34-bc5 > $logdir/nersc-anl-bc5-$c-d$s.log"
cmd6="env RCFTPRC=$configdir/rcftprc-nondirectio-$c-$s $rcftpbin -n -i -v < $taskdir/put-10.200.200.35-bc6 > $logdir/nersc-anl-bc6-$c-d$s.log"
cmd7="env RCFTPRC=$configdir/rcftprc-nondirectio-$c-$s $rcftpbin -n -i -v < $taskdir/put-10.200.200.36-bc7 > $logdir/nersc-anl-bc7-$c-d$s.log"
# vlan 655
cmd8="env RCFTPRC=$configdir/rcftprc-nondirectio-$c-$s $rcftpbin -n -i -v < $taskdir/put-10.200.202.30-bc8 > $logdir/nersc-anl-bc8-$c-d$s.log"
cmd9="env RCFTPRC=$configdir/rcftprc-nondirectio-$c-$s $rcftpbin -n -i -v < $taskdir/put-10.200.202.31-bc9 > $logdir/nersc-anl-bc9-$c-d$s.log"
cmd10="env RCFTPRC=$configdir/rcftprc-nondirectio-$c-$s $rcftpbin -n -i -v < $taskdir/put-10.200.202.32-bc10 > $logdir/nersc-anl-bc10-$c-d$s.log"
cmd11="env RCFTPRC=$configdir/rcftprc-nondirectio-$c-$s $rcftpbin -n -i -v < $taskdir/put-10.200.202.33-bc11 > $logdir/nersc-anl-bc11-$c-d$s.log"
cmd12="env RCFTPRC=$configdir/rcftprc-nondirectio-$c-$s $rcftpbin -n -i -v < $taskdir/put-10.200.202.34-bc12 > $logdir/nersc-anl-bc12-$c-d$s.log"
cmd13="env RCFTPRC=$configdir/rcftprc-nondirectio-$c-$s $rcftpbin -n -i -v < $taskdir/put-10.200.202.36-bc13 > $logdir/nersc-anl-bc13-$c-d$s.log"
cmd14="env RCFTPRC=$configdir/rcftprc-nondirectio-$c-$s $rcftpbin -n -i -v < $taskdir/put-10.200.202.37-bc14 > $logdir/nersc-anl-bc14-$c-d$s.log"

echo "#! /bin/bash" > put-$anl0171.sh
echo "#! /bin/bash" > put-$anl0172.sh
echo "#! /bin/bash" > put-$anl0173.sh
echo "#! /bin/bash" > put-$anl0174.sh
echo "#! /bin/bash" > put-$anl0175.sh
echo "#! /bin/bash" > put-$anl0181.sh
echo "#! /bin/bash" > put-$anl0182.sh
echo "#! /bin/bash" > put-$anl0176.sh
echo "#! /bin/bash" > put-$anl0177.sh
echo "#! /bin/bash" > put-$anl0178.sh
echo "#! /bin/bash" > put-$anl0179.sh
echo "#! /bin/bash" > put-$anl0180.sh
echo "#! /bin/bash" > put-$anl0192.sh
echo "#! /bin/bash" > put-$anl0193.sh

echo "while [ 1 ]; do" >> put-$anl0171.sh
echo "while [ 1 ]; do" >> put-$anl0172.sh
echo "while [ 1 ]; do" >> put-$anl0173.sh
echo "while [ 1 ]; do" >> put-$anl0174.sh
echo "while [ 1 ]; do" >> put-$anl0175.sh
echo "while [ 1 ]; do" >> put-$anl0181.sh
echo "while [ 1 ]; do" >> put-$anl0182.sh
echo "while [ 1 ]; do" >> put-$anl0176.sh
echo "while [ 1 ]; do" >> put-$anl0177.sh
echo "while [ 1 ]; do" >> put-$anl0178.sh
echo "while [ 1 ]; do" >> put-$anl0179.sh
echo "while [ 1 ]; do" >> put-$anl0180.sh
echo "while [ 1 ]; do" >> put-$anl0192.sh
echo "while [ 1 ]; do" >> put-$anl0193.sh

echo "ssh $username@$cvrani01" \"$cmd1\" >> put-$anl0171.sh
echo "ssh $username@$cvrani02" \"$cmd2\" >> put-$anl0172.sh
echo "ssh $username@$cvrani04" \"$cmd3\" >> put-$anl0173.sh
echo "ssh $username@$cvrani05" \"$cmd4\" >> put-$anl0174.sh
echo "ssh $username@$cvrani06" \"$cmd5\" >> put-$anl0175.sh
echo "ssh $username@$cvrani07" \"$cmd6\" >> put-$anl0181.sh
echo "ssh $username@$cvrani08" \"$cmd7\" >> put-$anl0182.sh
echo "ssh $username@$cvrani09" \"$cmd8\" >> put-$anl0176.sh
echo "ssh $username@$cvrani10" \"$cmd9\" >> put-$anl0177.sh
echo "ssh $username@$cvrani11" \"$cmd10\" >> put-$anl0178.sh
echo "ssh $username@$cvrani12" \"$cmd11\" >> put-$anl0179.sh
echo "ssh $username@$cvrani13" \"$cmd12\" >> put-$anl0180.sh
echo "ssh $username@$cvrani14" \"$cmd13\" >> put-$anl0192.sh
echo "ssh $username@$cvrani15" \"$cmd14\" >> put-$anl0193.sh

echo "done" >> put-$anl0171.sh
echo "done" >> put-$anl0172.sh
echo "done" >> put-$anl0173.sh
echo "done" >> put-$anl0174.sh
echo "done" >> put-$anl0175.sh
echo "done" >> put-$anl0181.sh
echo "done" >> put-$anl0182.sh
echo "done" >> put-$anl0176.sh
echo "done" >> put-$anl0177.sh
echo "done" >> put-$anl0178.sh
echo "done" >> put-$anl0179.sh
echo "done" >> put-$anl0180.sh
echo "done" >> put-$anl0192.sh
echo "done" >> put-$anl0193.sh

chmod +x put-*.sh

date "+%F %X" >> $logdir/datetime_start.log

./put-$anl0171.sh &
pid1=$!
./put-$anl0172.sh &
pid2=$!
./put-$anl0173.sh &
pid3=$!
./put-$anl0174.sh &
pid4=$!
./put-$anl0175.sh &
pid5=$!
./put-$anl0181.sh &
pid6=$!
./put-$anl0182.sh &
pid7=$!
./put-$anl0176.sh &
pid8=$!
./put-$anl0177.sh &
pid9=$!
./put-$anl0178.sh &
pid10=$!
./put-$anl0179.sh &
pid11=$!
./put-$anl0180.sh &
pid12=$!
./put-$anl0192.sh &
pid13=$!
./put-$anl0193.sh &
pid14=$!

wait $pid1 $pid2 $pid3 $pid4 $pid5 $pid6 $pid7 $pid8 $pid9 $pid10 $pid11 $pid12 $pid13 $pid14 
date "+%F %X" >> $logdir/datetime_end.log
	done
done

