#! /bin/bash
ssh shudong@128.55.56.225 "env RCFTPRC=/global/u2/s/shudong/rftp/config/rcftprc-nondirectio-128K-32 /global/u2/s/shudong/rftp/rftp-latest-bin/rcftp -n -i -v < /global/u2/s/shudong/rftp/task/put-10.200.200.94-bc2 > /global/u2/s/shudong/rftp/log/rcftp-nondirectio-bc2-128K-d32.log"
