#! /bin/bash

source ./define.sh
mkdir -p $taskdir
rm -rf $taskdir/*

# local
#for dir in 1 2 3 4 5 6 7
#do
#	echo "open 127.0.0.1 18139" > $taskdir/put-local-bc$dir
#	echo "user ftp ftp" >> $taskdir/put-local-bc$dir
#	echo "prompt" >> $taskdir/put-local-bc$dir
#	echo "lcd " $sourcedir >> $taskdir/put-local-bc$dir
#	echo "cd " $sinkdir >> $taskdir/put-local-bc$dir
#	echo "put bell_curve$dir" >> $taskdir/put-local-bc$dir
#	echo "bye" >> $taskdir/put-local-bc$dir
#done

#for host in $hosteths
#do
#	for dir in 1 2 3 4 5 6 7
#	do
#	echo "open $host 18139" > $taskdir/put-$host-bc$dir
#	echo "user ftp ftp" >> $taskdir/put-$host-bc$dir
#	echo "prompt" >> $taskdir/put-$host-bc$dir
#	echo "lcd $sourcedir" >> $taskdir/put-$host-bc$dir
#	echo "cd $sinkdir" >> $taskdir/put-$host-bc$dir
#	echo "put bell_curve$dir" >> $taskdir/put-$host-bc$dir
#	echo "bye" >> $taskdir/put-$host-bc$dir
#	done
#done

# create put ornl task
#for host in $ornlhosts
#do
	#for dir in 1 2 3 4 5 6 7 8 9 10
	#do
#echo "lcd $ornlsrc"

        echo "open $ornl01 18139" > $taskdir/put-$ornl01-bc1
	echo "user ftp ftp" >> $taskdir/put-$ornl01-bc1
	echo "prompt" >> $taskdir/put-$ornl01-bc1
	echo "lcd $ornlsrc" >> $taskdir/put-$ornl01-bc1
	echo "cd $ornlsinkdir" >> $taskdir/put-$ornl01-bc1
	echo "put data4" >> $taskdir/put-$ornl01-bc1
	echo "bye" >> $taskdir/put-$ornl01-bc1

        echo "open $ornl02 18139" > $taskdir/put-$ornl02-bc2
        echo "user ftp ftp" >> $taskdir/put-$ornl02-bc2
        echo "prompt" >> $taskdir/put-$ornl02-bc2
        echo "lcd $ornlsrc" >> $taskdir/put-$ornl02-bc2
        echo "cd $ornlsinkdir" >> $taskdir/put-$ornl02-bc2
        echo "put data6" >> $taskdir/put-$ornl02-bc2
        echo "bye" >> $taskdir/put-$ornl02-bc2

        echo "open $ornl03 18139" > $taskdir/put-$ornl03-bc3
        echo "user ftp ftp" >> $taskdir/put-$ornl03-bc3
        echo "prompt" >> $taskdir/put-$ornl03-bc3
        echo "lcd $ornlsrc" >> $taskdir/put-$ornl03-bc3
        echo "cd $ornlsinkdir" >> $taskdir/put-$ornl03-bc3
        echo "put 1pctto2x" >> $taskdir/put-$ornl03-bc3
        echo "bye" >> $taskdir/put-$ornl03-bc3

        echo "open $ornl04 18139" > $taskdir/put-$ornl04-bc4
        echo "user ftp ftp" >> $taskdir/put-$ornl04-bc4
        echo "prompt" >> $taskdir/put-$ornl04-bc4
        echo "lcd $ornlsrc" >> $taskdir/put-$ornl04-bc4
        echo "cd $ornlsinkdir" >> $taskdir/put-$ornl04-bc4
        echo "put data10" >> $taskdir/put-$ornl04-bc4
        echo "bye" >> $taskdir/put-$ornl04-bc4

        echo "open $ornl05 18139" > $taskdir/put-$ornl05-bc5
        echo "user ftp ftp" >> $taskdir/put-$ornl05-bc5
        echo "prompt" >> $taskdir/put-$ornl05-bc5
        echo "lcd $ornlsrc" >> $taskdir/put-$ornl05-bc5
        echo "cd $ornlsinkdir" >> $taskdir/put-$ornl05-bc5
        echo "put data11" >> $taskdir/put-$ornl05-bc5
        echo "bye" >> $taskdir/put-$ornl05-bc5

        echo "open $ornl06 18139" > $taskdir/put-$ornl06-bc6
        echo "user ftp ftp" >> $taskdir/put-$ornl06-bc6
        echo "prompt" >> $taskdir/put-$ornl06-bc6
        echo "lcd $ornlsrc" >> $taskdir/put-$ornl06-bc6
        echo "cd $ornlsinkdir" >> $taskdir/put-$ornl06-bc6
        echo "put data12" >> $taskdir/put-$ornl06-bc6
        echo "bye" >> $taskdir/put-$ornl06-bc6

        echo "open $ornl07 18139" > $taskdir/put-$ornl07-bc7
        echo "user ftp ftp" >> $taskdir/put-$ornl07-bc7
        echo "prompt" >> $taskdir/put-$ornl07-bc7
        echo "lcd $ornlsrc" >> $taskdir/put-$ornl07-bc7
        echo "cd $ornlsinkdir" >> $taskdir/put-$ornl07-bc7
        echo "put data13" >> $taskdir/put-$ornl07-bc7
        echo "bye" >> $taskdir/put-$ornl07-bc7

        echo "open $ornl08 18139" > $taskdir/put-$ornl08-bc8
        echo "user ftp ftp" >> $taskdir/put-$ornl08-bc8
        echo "prompt" >> $taskdir/put-$ornl08-bc8
        echo "lcd $ornlsrc" >> $taskdir/put-$ornl08-bc8
        echo "cd $ornlsinkdir" >> $taskdir/put-$ornl08-bc8
        echo "put data14" >> $taskdir/put-$ornl08-bc8
        echo "bye" >> $taskdir/put-$ornl08-bc8

        echo "open $ornl09 18139" > $taskdir/put-$ornl09-bc9
        echo "user ftp ftp" >> $taskdir/put-$ornl09-bc9
        echo "prompt" >> $taskdir/put-$ornl09-bc9
        echo "lcd $ornlsrc" >> $taskdir/put-$ornl09-bc9
        echo "cd $ornlsinkdir" >> $taskdir/put-$ornl09-bc9
        echo "put data16" >> $taskdir/put-$ornl09-bc9
        echo "bye" >> $taskdir/put-$ornl09-bc9

        echo "open $ornl10 18139" > $taskdir/put-$ornl10-bc10
        echo "user ftp ftp" >> $taskdir/put-$ornl10-bc10
        echo "prompt" >> $taskdir/put-$ornl10-bc10
        echo "lcd $ornlsrc" >> $taskdir/put-$ornl10-bc10
        echo "cd $ornlsinkdir" >> $taskdir/put-$ornl10-bc10
        echo "put data17" >> $taskdir/put-$ornl10-bc10
        echo "bye" >> $taskdir/put-$ornl10-bc10





	#done
#done

# create put ornl lustre task
#for host in $ornlhosts
#do
#	for dir in 1 2 3 4 5 6 7 8 9 10
#	do
#	echo "open $host 18139" > $taskdir/put-$host-lustre-bc$dir
#	echo "user ftp ftp" >> $taskdir/put-$host-lustre-bc$dir
#	echo "prompt" >> $taskdir/put-$host-lustre-bc$dir
#	echo "lcd $sourcedir" >> $taskdir/put-$host-lustre-bc$dir
#	echo "cd $ornlsinkdir" >> $taskdir/put-$host-lustre-bc$dir
#	echo "put bell_curve$dir" >> $taskdir/put-$host-lustre-bc$dir
#	echo "bye" >> $taskdir/put-$host-lustre-bc$dir
#	done
#done

# create put anl task
#for host in $anlhosts
#do
#	for dir in 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14
#	do
	echo "open $anl0171 18139" > $taskdir/put-$anl0171-bc1
	echo "user ftp ftp" >> $taskdir/put-$anl0171-bc1
	echo "prompt" >> $taskdir/put-$anl0171-bc1
	echo "lcd $anlsrc" >> $taskdir/put-$anl0171-bc1
	echo "cd $anlsinkdir" >> $taskdir/put-$anl0171-bc1
	echo "put slabcntl" >> $taskdir/put-$anl0171-bc1
	echo "bye" >> $taskdir/put-$anl0171-bc1

        echo "open $anl0172 18139" > $taskdir/put-$anl0172-bc2
        echo "user ftp ftp" >> $taskdir/put-$anl0172-bc2
        echo "prompt" >> $taskdir/put-$anl0172-bc2
        echo "lcd $anlsrc" >> $taskdir/put-$anl0172-bc2
        echo "cd $anlsinkdir" >> $taskdir/put-$anl0172-bc2
        echo "put commit" >> $taskdir/put-$anl0172-bc2
        echo "bye" >> $taskdir/put-$anl0172-bc2

        echo "open $anl0173 18139" > $taskdir/put-$anl0173-bc3
        echo "user ftp ftp" >> $taskdir/put-$anl0173-bc3
        echo "prompt" >> $taskdir/put-$anl0173-bc3
        echo "lcd $anlsrc" >> $taskdir/put-$anl0173-bc3
        echo "cd $anlsinkdir" >> $taskdir/put-$anl0173-bc3
        echo "put data1" >> $taskdir/put-$anl0173-bc3
        echo "bye" >> $taskdir/put-$anl0173-bc3

        echo "open $anl0174 18139" > $taskdir/put-$anl0174-bc4
        echo "user ftp ftp" >> $taskdir/put-$anl0174-bc4
        echo "prompt" >> $taskdir/put-$anl0174-bc4
        echo "lcd $anlsrc" >> $taskdir/put-$anl0174-bc4
        echo "cd $anlsinkdir" >> $taskdir/put-$anl0174-bc4
        echo "put data2" >> $taskdir/put-$anl0174-bc4
        echo "bye" >> $taskdir/put-$anl0174-bc4

        echo "open $anl0175 18139" > $taskdir/put-$anl0175-bc5
        echo "user ftp ftp" >> $taskdir/put-$anl0175-bc5
        echo "prompt" >> $taskdir/put-$anl0175-bc5
        echo "lcd $anlsrc" >> $taskdir/put-$anl0175-bc5
        echo "cd $anlsinkdir" >> $taskdir/put-$anl0175-bc5
        echo "put data3" >> $taskdir/put-$anl0175-bc5
        echo "bye" >> $taskdir/put-$anl0175-bc5


        echo "open $anl0176 18139" > $taskdir/put-$anl0176-bc6
        echo "user ftp ftp" >> $taskdir/put-$anl0176-bc6
        echo "prompt" >> $taskdir/put-$anl0176-bc6
        echo "lcd $anlsrc" >> $taskdir/put-$anl0176-bc6
        echo "cd $anlsinkdir" >> $taskdir/put-$anl0176-bc6
        echo "put data5" >> $taskdir/put-$anl0176-bc6
        echo "bye" >> $taskdir/put-$anl0176-bc6

        echo "open $anl0177 18139" > $taskdir/put-$anl0177-bc7
        echo "user ftp ftp" >> $taskdir/put-$anl0177-bc7
        echo "prompt" >> $taskdir/put-$anl0177-bc7
        echo "lcd $anlsrc" >> $taskdir/put-$anl0177-bc7
        echo "cd $anlsinkdir" >> $taskdir/put-$anl0177-bc7
        echo "put data7" >> $taskdir/put-$anl0177-bc7
        echo "bye" >> $taskdir/put-$anl0177-bc7

        echo "open $anl0178 18139" > $taskdir/put-$anl0178-bc8
        echo "user ftp ftp" >> $taskdir/put-$anl0178-bc8
        echo "prompt" >> $taskdir/put-$anl0178-bc8
        echo "lcd $anlsrc" >> $taskdir/put-$anl0178-bc8
        echo "cd $anlsinkdir" >> $taskdir/put-$anl0178-bc8
        echo "put data8" >> $taskdir/put-$anl0178-bc8
        echo "bye" >> $taskdir/put-$anl0178-bc8

        echo "open $anl0179 18139" > $taskdir/put-$anl0179-bc9
        echo "user ftp ftp" >> $taskdir/put-$anl0179-bc9
        echo "prompt" >> $taskdir/put-$anl0179-bc9
        echo "lcd $anlsrc" >> $taskdir/put-$anl0179-bc9
        echo "cd $anlsinkdir" >> $taskdir/put-$anl0179-bc9
        echo "put data9" >> $taskdir/put-$anl0179-bc9
        echo "bye" >> $taskdir/put-$anl0179-bc9

        echo "open $anl0180 18139" > $taskdir/put-$anl0180-bc10
        echo "user ftp ftp" >> $taskdir/put-$anl0180-bc10
        echo "prompt" >> $taskdir/put-$anl0180-bc10
        echo "lcd $anlsrc" >> $taskdir/put-$anl0180-bc10
        echo "cd $anlsinkdir" >> $taskdir/put-$anl0180-bc10
        echo "put data15" >> $taskdir/put-$anl0180-bc10
        echo "bye" >> $taskdir/put-$anl0180-bc10

        echo "open $anl0181 18139" > $taskdir/put-$anl0181-bc11
        echo "user ftp ftp" >> $taskdir/put-$anl0181-bc11
        echo "prompt" >> $taskdir/put-$anl0181-bc11
        echo "lcd $anlsrc" >> $taskdir/put-$anl0181-bc11
        echo "cd $anlsinkdir" >> $taskdir/put-$anl0181-bc11
        echo "put data18" >> $taskdir/put-$anl0181-bc11
        echo "bye" >> $taskdir/put-$anl0181-bc11

exit
