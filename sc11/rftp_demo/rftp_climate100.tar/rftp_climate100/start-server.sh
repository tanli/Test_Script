#! /bin/bash

env RFTPDRC=/global/u2/s/shudong/rftp/config/rftpdrc-b1M-p18139-dno /global/u2/s/shudong/rftp/rftp-latest-bin/rftpd -D