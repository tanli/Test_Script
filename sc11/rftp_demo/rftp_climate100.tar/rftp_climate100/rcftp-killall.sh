#! /bin/bash

source ./define.sh

killall -s 9 put*
for host in $hosts
do
	ssh $username@$host "killall -s 9 rcftp"
done

