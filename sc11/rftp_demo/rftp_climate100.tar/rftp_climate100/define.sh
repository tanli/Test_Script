#! /bin/bash

#Dir of config files
configdir=/global/u2/s/shudong/rftp/climate100/config

#Dir of the task list files
taskdir=/global/u2/s/shudong/rftp/climate100/task

#Dir of the log files
logdir=/global/u2/s/shudong/rftp/climate100/log

#Dir of the data sink on ORNL and ANL site
ornlsinkdir=/lustre/anifs/yren/sync/data/sink/
anlsinkdir=/home/dtyu/sc11/climate100/data/sink/

#Dir of the data source on NERSC sites
ornlsrc=/project/projectdirs/clim100/ipcc/cmip3/
anlsrc=/project/projectdirs/clim100/ipcc/cmip3/

#Dir of the rftp binarys
rftpdbin=/global/u2/s/shudong/rftp/rftp-latest-bin/rftpd
rcftpbin=/global/u2/s/shudong/rftp/rftp-latest-bin/rcftp

#The buffer size and stream size that you want to test
cbufsizs="16K 64K 128K 512K 1M 2M"
rcstreamnums="1 2 4 8 16 32"

#Your username on NERSC sites
username=shudong

#NERSC hosts that will be used 
cvrani01=128.55.56.224
cvrani02=128.55.56.225
#cvrani03=128.55.56.226
cvrani04=128.55.56.227
cvrani05=128.55.56.228
cvrani06=128.55.56.229
cvrani07=128.55.56.230
cvrani08=128.55.56.231
cvrani09=128.55.56.232
cvrani10=128.55.56.233
cvrani11=128.55.56.234
cvrani12=128.55.56.235
cvrani13=128.55.56.236
cvrani14=128.55.56.237
cvrani15=128.55.56.238
cvrani16=128.55.56.239

hosts="$cvrani01 $cvrani02 $cvrani04 $cvrani05 $cvrani06 $cvrani07 $cvrani08 $cvrani09 $cvrani10 $cvrani11 $cvrani12 $cvrani13 $cvrani14 $cvrani15 $cvrani16"

cvranieth01=10.200.200.1
cvranieth02=10.200.200.2
cvranieth03=10.200.200.3
cvranieth04=10.200.200.4
cvranieth05=10.200.200.5
cvranieth06=10.200.200.6
cvranieth07=10.200.200.7
cvranieth08=10.200.200.8
cvranieth09=10.200.200.9
cvranieth10=10.200.200.10
cvranieth11=10.200.200.11
cvranieth12=10.200.200.12
cvranieth13=10.200.200.13
cvranieth14=10.200.200.14
cvranieth15=10.200.200.15
cvranieth16=10.200.200.16

hosteths="$cvranieth01 $cvranieth02 $cvranieth04 $cvranieth05 $cvranieth06 $cvranieth07 $cvranieth08 $cvranieth09 $cvranieth10 $cvranieth11 $cvranieth12 $cvranieth13 $cvranieth14 $cvranieth15 $cvranieth16"

#ORNL sites will be used
ornl01=10.200.200.93
ornl02=10.200.200.94
ornl03=10.200.200.95
ornl04=10.200.200.96
ornl05=10.200.200.97
ornl06=10.200.200.98
ornl07=10.200.200.99
ornl08=10.200.200.100
ornl09=10.200.200.101
ornl10=10.200.200.102

ornlhosts="$ornl01 $ornl02 $ornl03 $ornl04 $ornl05 $ornl06 $ornl07 $ornl08 $ornl09 $ornl10"

#ANL sites will be used
anl0171=10.200.200.30
anl0172=10.200.200.31
anl0173=10.200.200.32
anl0174=10.200.200.33
anl0175=10.200.200.34
anl0176=10.200.202.30
anl0177=10.200.202.31
anl0178=10.200.202.32
anl0179=10.200.202.33
anl0180=10.200.202.34
anl0181=10.200.200.35
anl0182=10.200.200.36
anl0183=10.200.200.37
anl0184=10.200.200.38
anl0185=10.200.200.39
anl0192=10.200.202.36
anl0193=10.200.202.37
anl0194=10.200.202.38

anlhosts="$anl0171 $anl0172 $anl0173 $anl0174 $anl0175 $anl0176 $anl0177 $anl0178 $anl0179 $anl0180 $anl0181 $anl0182 $anl0183 $anl0184 $anl0185 $anl0192 $anl0193 $anl0194"

